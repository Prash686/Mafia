import { motion } from "framer-motion";
import { Clock, Filter, Search } from "lucide-react";
import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { mockAuditTrail } from "@/data/mockData";
import { Input } from "@/components/ui/input";

const actionColors: Record<string, string> = {
  case_created: "bg-info/15 text-info",
  risk_scored: "bg-destructive/15 text-destructive",
  typology_matched: "bg-primary/15 text-primary",
  data_enriched: "bg-success/15 text-success",
  narrative_generated: "bg-primary/15 text-primary",
  narrative_edited: "bg-info/15 text-info",
};

const AuditTrail = () => {
  const [search, setSearch] = useState("");
  const filtered = mockAuditTrail.filter(
    (e) =>
      e.description.toLowerCase().includes(search.toLowerCase()) ||
      e.actor.toLowerCase().includes(search.toLowerCase()) ||
      e.details.toLowerCase().includes(search.toLowerCase())
  );

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Audit Trail</h1>
          <p className="text-sm text-muted-foreground mt-1">Complete transparency into AI reasoning and data usage</p>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search audit entries..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>

        <div className="space-y-4">
          {filtered.map((entry, i) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="glass-card rounded-xl p-5"
            >
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                  <Clock className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{entry.description}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{entry.actor} · {formatDate(entry.timestamp)}</p>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${actionColors[entry.action] || "bg-muted text-muted-foreground"}`}>
                      {entry.action.replace(/_/g, " ")}
                    </span>
                  </div>
                  <p className="text-xs text-foreground/70 leading-relaxed">{entry.details}</p>
                  {entry.dataPoints.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {entry.dataPoints.map((dp) => (
                        <span key={dp} className="inline-flex px-2 py-0.5 rounded bg-primary/10 text-[10px] font-mono text-primary">
                          {dp}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default AuditTrail;
