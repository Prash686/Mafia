import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Search, Filter } from "lucide-react";
import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import StatusBadge from "@/components/StatusBadge";
import RiskBadge from "@/components/RiskBadge";
import { mockCases } from "@/data/mockData";
import { Input } from "@/components/ui/input";

const Cases = () => {
  const [search, setSearch] = useState("");
  const filtered = mockCases.filter(
    (c) =>
      c.subject.toLowerCase().includes(search.toLowerCase()) ||
      c.id.toLowerCase().includes(search.toLowerCase()) ||
      c.typology.toLowerCase().includes(search.toLowerCase())
  );

  const formatAmount = (amount: number, currency: string) => {
    if (currency === "INR") return `₹${(amount / 100000).toFixed(1)}L`;
    return `$${(amount / 1000).toFixed(0)}K`;
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Cases</h1>
            <p className="text-sm text-muted-foreground mt-1">{mockCases.length} total cases</p>
          </div>
          <Link
            to="/generate"
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            + New SAR
          </Link>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search cases by subject, ID, or typology..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>

        <div className="glass-card rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["Case ID", "Subject", "Typology", "Amount", "Risk", "Status", "Assignee"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((c, i) => (
                <motion.tr
                  key={c.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="hover:bg-accent/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <Link to={`/cases/${c.id}`} className="font-mono text-xs text-primary hover:underline">
                      {c.id}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-foreground">{c.subject}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{c.typology}</td>
                  <td className="px-4 py-3 font-mono text-xs text-foreground">{formatAmount(c.totalAmount, c.currency)}</td>
                  <td className="px-4 py-3"><RiskBadge score={c.riskScore} /></td>
                  <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{c.assignee}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
};

export default Cases;
