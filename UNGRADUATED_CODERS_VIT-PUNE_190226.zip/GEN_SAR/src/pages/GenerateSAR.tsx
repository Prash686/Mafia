import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Loader2, ChevronRight } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

const GenerateSAR = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedNarrative, setGeneratedNarrative] = useState("");
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState({
    subjectName: "",
    subjectType: "Individual",
    accountNumber: "",
    alertIds: "",
    transactionSummary: "",
    kycNotes: "",
    suspicionBasis: "",
  });

  const update = (field: string, value: string) =>
    setFormData((prev) => ({ ...prev, [field]: value }));

  const handleGenerate = async () => {
    setIsGenerating(true);

    // Simulate AI generation with realistic delay
    await new Promise((r) => setTimeout(r, 3000));

    const narrative = `Subject: ${formData.subjectName} (${formData.subjectType})
Account: ${formData.accountNumber}

1. SUMMARY OF SUSPICIOUS ACTIVITY

This Suspicious Activity Report is filed in connection with unusual transaction activity associated with ${formData.subjectName}. The activity described herein was identified through the bank's automated transaction monitoring system and subsequent investigation by the compliance team.

2. SUBJECT INFORMATION

${formData.subjectName} maintains account ${formData.accountNumber} with the institution. ${formData.kycNotes || "KYC review indicates no prior suspicious activity filings against this subject."}

3. DESCRIPTION OF SUSPICIOUS ACTIVITY

${formData.transactionSummary || "Transaction monitoring alerts were triggered based on unusual patterns in the subject's account activity."}

${formData.suspicionBasis || "The totality of the transaction activity, including the volume, velocity, and counterparties involved, is inconsistent with the subject's stated business profile and known financial history."}

4. REGULATORY INDICATORS

The activity described above is consistent with indicators identified in applicable regulatory guidance for potential money laundering and/or terrorist financing, including but not limited to:
- Structuring transactions to avoid reporting thresholds
- Rapid movement of funds through multiple accounts
- Transactions inconsistent with the customer's risk profile

5. ACTIONS TAKEN

The institution has filed this SAR with the Financial Intelligence Unit (FIU-IND) and will continue to monitor the subject's accounts for further suspicious activity. Enhanced due diligence measures have been applied to the subject's account.

This report was generated with AI assistance and reviewed by a compliance analyst before submission.`;

    setGeneratedNarrative(narrative);
    setIsGenerating(false);
    setStep(3);
    toast({ title: "Narrative Generated", description: "AI-generated draft is ready for review." });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Generate SAR Narrative</h1>
          <p className="text-sm text-muted-foreground mt-1">Input case data to generate a regulatory-ready narrative</p>
        </div>

        {/* Progress steps */}
        <div className="flex items-center gap-2">
          {[
            { num: 1, label: "Subject Info" },
            { num: 2, label: "Activity Details" },
            { num: 3, label: "Review Narrative" },
          ].map((s, i) => (
            <div key={s.num} className="flex items-center gap-2">
              <div
                className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  step >= s.num ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                }`}
              >
                {s.num}
              </div>
              <span className={`text-xs font-medium ${step >= s.num ? "text-foreground" : "text-muted-foreground"}`}>
                {s.label}
              </span>
              {i < 2 && <ChevronRight className="h-4 w-4 text-muted-foreground mx-2" />}
            </div>
          ))}
        </div>

        {step === 1 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-xl p-6 space-y-5">
            <h3 className="text-sm font-semibold text-foreground">Subject Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Subject Name</label>
                <Input value={formData.subjectName} onChange={(e) => update("subjectName", e.target.value)}
                  placeholder="e.g. Rajesh Kumar Sharma" className="bg-background border-border" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Subject Type</label>
                <select
                  value={formData.subjectType}
                  onChange={(e) => update("subjectType", e.target.value)}
                  className="flex h-10 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
                >
                  <option value="Individual">Individual</option>
                  <option value="Entity">Entity</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Account Number</label>
                <Input value={formData.accountNumber} onChange={(e) => update("accountNumber", e.target.value)}
                  placeholder="e.g. XXXX-XXXX-4521" className="bg-background border-border" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Alert IDs</label>
                <Input value={formData.alertIds} onChange={(e) => update("alertIds", e.target.value)}
                  placeholder="e.g. TXN-2024-00147, TXN-2024-00148" className="bg-background border-border" />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">KYC Notes</label>
              <Textarea value={formData.kycNotes} onChange={(e) => update("kycNotes", e.target.value)}
                placeholder="Customer profile, occupation, account history..." className="bg-background border-border min-h-[80px]" />
            </div>
            <div className="flex justify-end">
              <Button onClick={() => setStep(2)} disabled={!formData.subjectName}>
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-xl p-6 space-y-5">
            <h3 className="text-sm font-semibold text-foreground">Activity Details</h3>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Transaction Summary</label>
              <Textarea value={formData.transactionSummary} onChange={(e) => update("transactionSummary", e.target.value)}
                placeholder="Describe the suspicious transaction pattern..."
                className="bg-background border-border min-h-[120px]" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Basis of Suspicion</label>
              <Textarea value={formData.suspicionBasis} onChange={(e) => update("suspicionBasis", e.target.value)}
                placeholder="Why is this activity suspicious? Reference typologies if applicable..."
                className="bg-background border-border min-h-[120px]" />
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
              <Button onClick={handleGenerate} disabled={isGenerating}>
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" /> Generate Narrative
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        )}

        {step === 3 && generatedNarrative && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="glass-card rounded-xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-foreground">Generated Narrative</h3>
                <div className="flex items-center gap-2 text-xs text-primary">
                  <Sparkles className="h-3 w-3" /> AI Generated · Confidence 87%
                </div>
              </div>
              <Textarea
                value={generatedNarrative}
                onChange={(e) => setGeneratedNarrative(e.target.value)}
                className="min-h-[400px] font-mono text-sm bg-background border-border leading-relaxed"
              />
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>← Regenerate</Button>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => {
                    toast({ title: "Draft Saved", description: "Narrative saved to case SAR-2024-0892." });
                  }}>
                    Save Draft
                  </Button>
                  <Button onClick={() => {
                    toast({ title: "Submitted for Review", description: "Narrative sent to reviewer for approval." });
                    navigate("/cases");
                  }}>
                    Submit for Review
                  </Button>
                </div>
              </div>
            </div>

            {/* Generation audit trail */}
            <div className="glass-card rounded-xl p-6 space-y-3">
              <h3 className="text-sm font-semibold text-foreground">Generation Audit Trail</h3>
              <div className="space-y-2">
                {[
                  { label: "Data Sources Used", value: "Transaction alerts, KYC records, account history" },
                  { label: "Template Applied", value: "SAR-TEMPLATE-IND-v3.2" },
                  { label: "Typology Matched", value: "Structuring / Layering (FATF 4.2.1, 4.3.2)" },
                  { label: "Risk Factors", value: "High velocity transfers, multiple unique senders, immediate outward wire" },
                  { label: "Confidence Score", value: "87% (based on data completeness and pattern match strength)" },
                ].map((item) => (
                  <div key={item.label} className="flex items-start gap-3">
                    <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-40 shrink-0 pt-0.5">{item.label}</span>
                    <span className="text-xs text-foreground/80">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
};

export default GenerateSAR;
