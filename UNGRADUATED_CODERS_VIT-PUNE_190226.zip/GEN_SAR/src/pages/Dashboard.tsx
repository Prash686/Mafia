import { motion } from "framer-motion";
import { FileText, AlertTriangle, CheckCircle, Clock, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import StatCard from "@/components/StatCard";
import StatusBadge from "@/components/StatusBadge";
import RiskBadge from "@/components/RiskBadge";
import { mockCases } from "@/data/mockData";

const Dashboard = () => {
  const stats = {
    total: mockCases.length,
    drafts: mockCases.filter((c) => c.status === "draft").length,
    inReview: mockCases.filter((c) => c.status === "review").length,
    filed: mockCases.filter((c) => c.status === "filed").length,
  };

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">SAR case overview and compliance metrics</p>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <StatCard
            label="Total Cases"
            value={stats.total}
            icon={<FileText className="h-5 w-5 text-primary" />}
            trend="+2 this week"
          />
          <StatCard
            label="Pending Drafts"
            value={stats.drafts}
            icon={<Clock className="h-5 w-5 text-primary" />}
          />
          <StatCard
            label="In Review"
            value={stats.inReview}
            icon={<AlertTriangle className="h-5 w-5 text-primary" />}
          />
          <StatCard
            label="Filed with FIU"
            value={stats.filed}
            icon={<CheckCircle className="h-5 w-5 text-primary" />}
          />
        </div>

        <div className="glass-card rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Recent Cases</h2>
            <Link to="/cases" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="divide-y divide-border">
            {mockCases.map((c, i) => (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
              >
                <Link
                  to={`/cases/${c.id}`}
                  className="flex items-center gap-6 px-6 py-4 hover:bg-accent/50 transition-colors"
                >
                  <span className="font-mono text-xs text-muted-foreground w-32">{c.id}</span>
                  <span className="flex-1 text-sm font-medium text-foreground">{c.subject}</span>
                  <span className="text-xs text-muted-foreground w-40">{c.typology}</span>
                  <RiskBadge score={c.riskScore} />
                  <StatusBadge status={c.status} />
                  <span className="text-xs text-muted-foreground w-24">{c.assignee}</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
