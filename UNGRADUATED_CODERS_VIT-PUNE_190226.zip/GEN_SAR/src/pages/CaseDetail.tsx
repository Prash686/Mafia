import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Edit3, CheckCircle, Send, Clock, AlertTriangle, User, Building } from "lucide-react";
import AppLayout from "@/components/AppLayout";
import StatusBadge from "@/components/StatusBadge";
import RiskBadge from "@/components/RiskBadge";
import { mockCases, mockAuditTrail } from "@/data/mockData";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const CaseDetail = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const sarCase = mockCases.find((c) => c.id === id);
  const [narrative, setNarrative] = useState(sarCase?.narrative || "");
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<"narrative" | "transactions" | "audit">("narrative");

  if (!sarCase) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <p className="text-muted-foreground">Case not found</p>
        </div>
      </AppLayout>
    );
  }

  const formatAmount = (amount: number) => `₹${(amount / 100000).toFixed(1)}L`;
  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

  const handleApprove = () => {
    toast({ title: "Narrative Approved", description: "SAR narrative has been approved and queued for filing." });
  };

  const handleSave = () => {
    setIsEditing(false);
    toast({ title: "Narrative Saved", description: "Changes saved to draft." });
  };

  const auditActionIcons: Record<string, typeof Clock> = {
    case_created: AlertTriangle,
    risk_scored: AlertTriangle,
    typology_matched: AlertTriangle,
    data_enriched: User,
    narrative_generated: Edit3,
    narrative_edited: Edit3,
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link to="/cases" className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center hover:bg-accent transition-colors">
            <ArrowLeft className="h-4 w-4 text-foreground" />
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold text-foreground">{sarCase.subject}</h1>
              <StatusBadge status={sarCase.status} />
            </div>
            <p className="text-xs text-muted-foreground font-mono mt-1">{sarCase.id} · {sarCase.typology}</p>
          </div>
          <RiskBadge score={sarCase.riskScore} size="md" />
        </div>

        {/* Info cards */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Subject Type", value: sarCase.subjectType, icon: sarCase.subjectType === "Individual" ? User : Building },
            { label: "Total Amount", value: formatAmount(sarCase.totalAmount), icon: AlertTriangle },
            { label: "Alerts", value: sarCase.alertCount.toString(), icon: AlertTriangle },
            { label: "Assignee", value: sarCase.assignee, icon: User },
          ].map((item) => (
            <div key={item.label} className="glass-card rounded-xl p-4">
              <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{item.label}</p>
              <p className="mt-1 text-sm font-semibold text-foreground">{item.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-border">
          {(["narrative", "transactions", "audit"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab === "narrative" ? "Narrative" : tab === "transactions" ? "Transactions" : "Audit Trail"}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {activeTab === "narrative" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-foreground">SAR Narrative</h3>
              <div className="flex gap-2">
                {isEditing ? (
                  <Button size="sm" onClick={handleSave}>Save Draft</Button>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                    <Edit3 className="h-3 w-3 mr-1.5" /> Edit
                  </Button>
                )}
                <Button size="sm" onClick={handleApprove} className="bg-success text-success-foreground hover:bg-success/90">
                  <CheckCircle className="h-3 w-3 mr-1.5" /> Approve
                </Button>
              </div>
            </div>
            {narrative ? (
              isEditing ? (
                <Textarea
                  value={narrative}
                  onChange={(e) => setNarrative(e.target.value)}
                  className="min-h-[300px] font-mono text-sm bg-background border-border"
                />
              ) : (
                <div className="prose prose-sm prose-invert max-w-none">
                  {narrative.split("\n\n").map((p, i) => (
                    <p key={i} className="text-sm text-foreground/90 leading-relaxed">{p}</p>
                  ))}
                </div>
              )
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Edit3 className="h-8 w-8 text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">No narrative generated yet</p>
                <Link to="/generate" className="mt-3 text-xs text-primary hover:underline">
                  Generate narrative →
                </Link>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "transactions" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-xl overflow-hidden">
            {sarCase.transactions.length > 0 ? (
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    {["Txn ID", "Date", "Type", "Amount", "From / To", "Risk", "Flag Reason"].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sarCase.transactions.map((t) => (
                    <tr key={t.id} className="hover:bg-accent/30">
                      <td className="px-4 py-3 font-mono text-xs text-primary">{t.id}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{t.date}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{t.type}</td>
                      <td className="px-4 py-3 font-mono text-xs text-foreground">{formatAmount(t.amount)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{t.sender} → {t.receiver}</td>
                      <td className="px-4 py-3"><RiskBadge score={t.riskScore} /></td>
                      <td className="px-4 py-3 text-xs text-muted-foreground max-w-xs truncate">{t.flagReason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="py-16 text-center text-sm text-muted-foreground">No transaction data available for this case</div>
            )}
          </motion.div>
        )}

        {activeTab === "audit" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-0">
            {mockAuditTrail.map((entry, i) => {
              const Icon = auditActionIcons[entry.action] || Clock;
              return (
                <div key={entry.id} className="relative pl-8 pb-6">
                  {i < mockAuditTrail.length - 1 && (
                    <div className="absolute left-[15px] top-8 bottom-0 w-px bg-border" />
                  )}
                  <div className="absolute left-0 top-1 h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
                    <Icon className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <div className="glass-card rounded-xl p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-medium text-foreground">{entry.description}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{entry.actor} · {formatDate(entry.timestamp)}</p>
                      </div>
                    </div>
                    <p className="mt-2 text-xs text-foreground/70 leading-relaxed">{entry.details}</p>
                    {entry.dataPoints.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {entry.dataPoints.map((dp) => (
                          <span key={dp} className="inline-flex px-2 py-0.5 rounded bg-primary/10 text-[10px] font-mono text-primary">
                            {dp}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
};

export default CaseDetail;
