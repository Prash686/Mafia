export interface TransactionAlert {
  id: string;
  date: string;
  amount: number;
  currency: string;
  type: string;
  sender: string;
  receiver: string;
  accountNumber: string;
  flagReason: string;
  riskScore: number;
}

export interface SarCase {
  id: string;
  status: "draft" | "review" | "approved" | "filed";
  priority: "low" | "medium" | "high" | "critical";
  subject: string;
  subjectType: "Individual" | "Entity";
  createdAt: string;
  updatedAt: string;
  assignee: string;
  alertCount: number;
  totalAmount: number;
  currency: string;
  typology: string;
  riskScore: number;
  transactions: TransactionAlert[];
  narrative: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  description: string;
  details: string;
  dataPoints: string[];
}
