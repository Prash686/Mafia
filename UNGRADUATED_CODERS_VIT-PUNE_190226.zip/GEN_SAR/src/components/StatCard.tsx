import { motion } from "framer-motion";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  className?: string;
}

const StatCard = ({ label, value, icon, trend, className }: StatCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    className={cn("glass-card rounded-xl p-5", className)}
  >
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="mt-2 text-2xl font-bold text-foreground font-mono">{value}</p>
        {trend && <p className="mt-1 text-xs text-primary font-medium">{trend}</p>}
      </div>
      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
        {icon}
      </div>
    </div>
  </motion.div>
);

export default StatCard;
