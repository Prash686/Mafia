import { Shield, FileText, AlertTriangle, Clock, BarChart3, Sun, Moon } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useTheme } from "@/hooks/useTheme";

const navItems = [
  { to: "/", icon: BarChart3, label: "Dashboard" },
  { to: "/cases", icon: FileText, label: "Cases" },
  { to: "/generate", icon: AlertTriangle, label: "Generate SAR" },
  { to: "/audit", icon: Clock, label: "Audit Trail" },
];

const AppSidebar = () => {
  const location = useLocation();
  const { theme, toggle } = useTheme();

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col z-50">
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center glow-amber">
            <Shield className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-foreground tracking-tight">SAR Generator</h1>
            <p className="text-[11px] text-muted-foreground font-mono">COMPLIANCE · AI</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                isActive
                  ? "bg-primary/10 text-primary glow-amber"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border space-y-2">
        <button
          onClick={toggle}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          {theme === "dark" ? "Lite Mode" : "Dark Mode"}
        </button>
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
            <span className="text-xs font-semibold text-secondary-foreground">PM</span>
          </div>
          <div>
            <p className="text-xs font-medium text-foreground">Priya Mehta</p>
            <p className="text-[10px] text-muted-foreground">Senior Analyst</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default AppSidebar;
