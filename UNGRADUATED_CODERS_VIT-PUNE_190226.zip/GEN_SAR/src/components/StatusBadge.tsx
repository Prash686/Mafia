import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: "draft" | "review" | "approved" | "filed";
}

const statusConfig = {
  draft: { label: "Draft", className: "bg-muted text-muted-foreground" },
  review: { label: "In Review", className: "bg-primary/15 text-primary" },
  approved: { label: "Approved", className: "bg-success/15 text-success" },
  filed: { label: "Filed", className: "bg-info/15 text-info" },
};

const StatusBadge = ({ status }: StatusBadgeProps) => {
  const config = statusConfig[status];
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold tracking-wide uppercase", config.className)}>
      {config.label}
    </span>
  );
};

export default StatusBadge;
