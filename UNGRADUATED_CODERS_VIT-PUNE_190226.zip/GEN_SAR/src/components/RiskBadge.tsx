import { cn } from "@/lib/utils";

interface RiskBadgeProps {
  score: number;
  size?: "sm" | "md";
}

const RiskBadge = ({ score, size = "sm" }: RiskBadgeProps) => {
  const level = score >= 90 ? "critical" : score >= 70 ? "high" : score >= 50 ? "medium" : "low";

  return (
    <div className={cn("flex items-center gap-1.5", size === "md" && "gap-2")}>
      <div
        className={cn(
          "rounded-full",
          size === "sm" ? "h-2 w-2" : "h-2.5 w-2.5",
          level === "critical" && "bg-destructive animate-pulse",
          level === "high" && "bg-primary",
          level === "medium" && "bg-info",
          level === "low" && "bg-success"
        )}
      />
      <span
        className={cn(
          "font-mono font-semibold",
          size === "sm" ? "text-xs" : "text-sm",
          level === "critical" && "text-destructive",
          level === "high" && "text-primary",
          level === "medium" && "text-info",
          level === "low" && "text-success"
        )}
      >
        {score}
      </span>
    </div>
  );
};

export default RiskBadge;
